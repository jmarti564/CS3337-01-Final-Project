from django.urls import path
from . import views

app_name = 'bookMng'  # <- You MUST have this line to use {% url 'bookMng:something' %}

urlpatterns = [
    path('', views.index, name='index'),
    path('postbook/', views.postbook, name='postbook'),
    path('displaybooks/', views.displaybooks, name='displaybooks'),
    path('mybooks/', views.mybooks, name='mybooks'),
    path('book/<int:book_id>/', views.book_detail, name='book_detail'),
    path('book/delete/<int:book_id>/', views.book_delete, name='book_delete'),

    path('search/', views.search_books, name='search_books'),
    path('favorites/', views.favorites, name='favorites'),
    path('cart/', views.cart, name='cart'),

    path('add_to_cart/<int:book_id>/', views.add_to_cart, name='add_to_cart'),
    path('update_cart/<int:cart_item_id>/', views.update_cart, name='update_cart'),

    path('add_comment/<int:book_id>/', views.add_comment, name='add_comment'),
    path('delete_comment/<int:comment_id>/', views.delete_comment, name='delete_comment'),
    path('toggle_favorite/<int:book_id>/', views.toggle_favorite, name='toggle_favorite'),

    path('register/', views.Register.as_view(), name='register'),
]
